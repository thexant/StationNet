StationNet.start(async (ui) => {
  // Game Configuration
  const COLS = 4;
  const ROWS = 4;
  const CELL_SIZE = 70;
  const CANVAS_WIDTH = COLS * CELL_SIZE;
  const CANVAS_HEIGHT = ROWS * CELL_SIZE;

  // State Variables
  let grid = [];
  let score = 0;
  let highScore = 0;
  let status = "playing"; // "playing" | "gameover"
  let timerId = null;

  // Load existing personal high score
  try {
    const saved = await ui.storage.get("high_score");
    if (saved) highScore = saved;
  } catch (e) {
    highScore = 0;
  }

  function initGame() {
    grid = [];
    for (let r = 0; r < ROWS; r++) {
      const row = [];
      for (let c = 0; c < COLS; c++) {
        // Core levels: 1 (Cool/Blue) to 5 (Critical/Red)
        row.push(Math.floor(Math.random() * 2) + 1);
      }
      grid.push(row);
    }
    score = 0;
    status = "playing";
  }

  function tick() {
    if (status !== "playing") return;

    // Heat up a random core cell
    const r = Math.floor(Math.random() * ROWS);
    const c = Math.floor(Math.random() * COLS);
    grid[r][c]++;

    // Check for critical meltdown conditions
    if (grid[r][c] > 5) {
      status = "gameover";
      if (score > highScore) {
        highScore = score;
        ui.storage.set("high_score", highScore);
        ui.scores.submit(highScore);
      }
    } else {
      score += 10;
    }

    renderUI();
  }

  function coolCell(r, c) {
    if (status !== "playing") return;

    if (grid[r][c] > 1) {
      grid[r][c]--;
      score += 5;
    } else {
      // Penalty for over-cooling stable cores
      score = Math.max(0, score - 5);
    }

    renderUI();
  }

  function triggerCoolantFlush() {
    if (status !== "playing") return;

    // Cool all cores by 1 level
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (grid[r][c] > 1) grid[r][c]--;
      }
    }
    score = Math.max(0, score - 20); // Emergency flush cost
    renderUI();
  }

  function renderUI() {
    // Generate visual commands for the canvas
    const commands = [];

    // Background
    commands.push({
      type: "rect",
      x: 0,
      y: 0,
      width: CANVAS_WIDTH,
      height: CANVAS_HEIGHT,
      color: "#111827"
    });

    // Render Cores
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const val = grid[r][c];
        const x = c * CELL_SIZE + 4;
        const y = r * CELL_SIZE + 4;
        const size = CELL_SIZE - 8;

        // Temperature color mapping
        let color = "#3B82F6"; // 1: Safe Blue
        if (val === 2) color = "#10B981"; // Green
        if (val === 3) color = "#FBBF24"; // Yellow
        if (val === 4) color = "#F97316"; // Orange
        if (val >= 5) color = "#EF4444"; // 5: Critical Red

        commands.push({
          type: "rect",
          x,
          y,
          width: size,
          height: size,
          color
        });

        commands.push({
          type: "text",
          x: x + size / 2 - 6,
          y: y + size / 2 + 6,
          text: String(val),
          color: "#FFFFFF"
        });
      }
    }

    // Build main screen elements
    const elements = [
      ui.title("☢️ Reactor Meltdown"),
      ui.text(`Status: ${status === "playing" ? "ONLINE" : "CRITICAL MELTDOWN!"}`),
      ui.text(`Current Score: ${score}  |  Personal Best: ${highScore}`),
      ui.canvas(CANVAS_WIDTH, CANVAS_HEIGHT, commands, {
        onPointer: ({ x, y, phase }) => {
          if (phase === "start" && status === "playing") {
            const col = Math.floor(x / CELL_SIZE);
            const row = Math.floor(y / CELL_SIZE);
            if (row >= 0 && row < ROWS && col >= 0 && col < COLS) {
              coolCell(row, col);
            }
          }
        }
      })
    ];

    if (status === "playing") {
      elements.push(
        ui.button("Emergency Coolant Flush (-20 pts)", () => {
          triggerCoolantFlush();
        })
      );
    } else {
      elements.push(
        ui.text("⚠️ Core breach occurred! Manage temperatures before they hit 6!"),
        ui.button("Restart Reactor", () => {
          initGame();
          renderUI();
        })
      );
    }

    ui.render(...elements);
  }

  // Handle visibility changes to pause processing when tab is hidden
  ui.onVisibility((state) => {
    if (state === "hidden" && timerId) {
      clearInterval(timerId);
      timerId = null;
    } else if (state === "visible" && !timerId && status === "playing") {
      timerId = ui.interval(tick, 1000);
    }
  });

  ui.onCleanup(() => {
    if (timerId) clearInterval(timerId);
  });

  // Start game and interval
  initGame();
  timerId = ui.interval(tick, 1000);
  renderUI();
});